<?php

$rootDir = dirname(__DIR__);

require_once $rootDir . '/vendor/autoload.php';
require_once $rootDir . '/app/bootstrap.php';
