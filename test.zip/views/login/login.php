<?php
$this->title = 'Login Page';
?>

<?php include '../views/_parts/header.php' ?>
<?php include '../views/_parts/login-form.php' ?>
<?php include '../views/_parts/footer.php' ?>
