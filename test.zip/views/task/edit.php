<?php
$this->title = 'Edit Task';
?>

<?php include '../views/_parts/header.php' ?>
<?php include '../views/_parts/navbar.php' ?>
<?php include '../views/_parts/edit-form.php' ?>
<?php include '../views/_parts/footer.php' ?>
