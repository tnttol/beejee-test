<?php

return [
    '/'            => 'task/list',
    '/add'         => 'task/add',
    '/edit'        => 'task/edit',
    '/insert'      => 'task/insert',
    '/update'      => 'task/update',
    '/login'       => 'login/login',
    '/login-check' => 'login/check',
    '/logout'      => 'login/logout',
];
