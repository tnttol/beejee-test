<?php

return [
    'db_host'     => 'localhost',
    'db_name'     => 'toltnt',
    'db_user'     => 'jeebeejee',
    'db_password' => 'qwwQWW12321'
];
