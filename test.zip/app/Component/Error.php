<?php

namespace App\Component;

/**
 * Class Error
 */
class Error
{
    /**
     * @param int    $level   Error level
     * @param string $message Error message
     * @param string $file    Filename the error was raised in
     * @param int    $line    Line number in the file
     *
     * @return void
     */
    public static function errorHandler($level, $message, $file, $line)
    {
        throw new \ErrorException($message, 0, $level, $file, $line);
    }

    /**
     * @param \Exception $exception The exception
     *
     * @return void
     */
    public static function exceptionHandler($exception)
    {
        $code = $exception->getCode();
        $code = $code === 404 ? $code : 500;

        http_response_code($code);

        $errors = [
            'Uncaught exception: "' . get_class($exception) . '"',
            'Message: "' . $exception->getMessage() . '"',
            'Stack trace: ' . $exception->getTraceAsString(),
            'Thrown in "' . $exception->getFile() . '" on line ' . $exception->getLine()
        ];

        if (Config::$SHOW_ERRORS) {
            echo '<h1>Fatal error</h1>';

            foreach ($errors as $e) {
                echo '<p>' . $e . '</p>';
            }
        } else {
            $log = Config::$ROOT_DIR . '/logs/' . date('Y-m-d') . '.txt';
            ini_set('error_log', $log);
            $message = implode(PHP_EOL, $errors);
            error_log($message);

            (new View)->render('errors/' . $code);
        }
    }
}
