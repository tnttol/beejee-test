<?php

namespace App\Component;

/**
 * Class Config
 */
class Config
{
    /** @var bool */
    public static $SHOW_ERRORS = true;
    /** @var string */
    public static $ROOT_DIR;
}
